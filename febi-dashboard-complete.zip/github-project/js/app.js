/**
 * FEBI Dashboard - Main Application
 * Handles all UI logic and user interactions
 */

// Global State
let currentUser = null;
let currentSection = 'home';

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  hideLoading();
  setupEventListeners();
  checkAuth();
});

function hideLoading() {
  setTimeout(() => {
    document.getElementById('loadingScreen').classList.add('hidden');
  }, 500);
}

// ============= AUTHENTICATION =============
function setupEventListeners() {
  // Login tabs
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.form-section').forEach(s => s.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
    });
  });

  // Login form
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  
  // Register forms
  document.getElementById('registerMahasiswaForm').addEventListener('submit', (e) => handleRegister(e, 'mahasiswa'));
  document.getElementById('registerDosenForm').addEventListener('submit', (e) => handleRegister(e, 'dosen'));
  
  // Logout
  document.getElementById('logoutBtn').addEventListener('click', handleLogout);
  
  // Navigation
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      navigateToSection(link.dataset.section);
    });
  });
}

function checkAuth() {
  const user = sessionStorage.getItem('currentUser');
  if (user) {
    currentUser = JSON.parse(user);
    showDashboard();
  } else {
    showLogin();
  }
}

function handleLogin(e) {
  e.preventDefault();
  
  const id = document.getElementById('loginId').value.trim();
  const password = document.getElementById('loginPassword').value;
  
  const users = storage.getCollection('users');
  const user = users.find(u => u.id === id && u.password === password);
  
  if (user) {
    currentUser = user;
    sessionStorage.setItem('currentUser', JSON.stringify(user));
    showAlert('loginAlert', 'Login berhasil!', 'success');
    setTimeout(() => {
      showDashboard();
    }, 500);
  } else {
    showAlert('loginAlert', 'ID atau password salah!', 'error');
  }
}

function handleRegister(e, role) {
  e.preventDefault();
  
  const form = e.target;
  const formData = new FormData(form);
  
  const newUser = {
    id: formData.get('id'),
    password: formData.get('password'),
    role: role,
    nama: formData.get('nama'),
    email: formData.get('email'),
    registeredAt: new Date().toISOString()
  };
  
  // Check if ID exists
  const users = storage.getCollection('users');
  if (users.find(u => u.id === newUser.id)) {
    showAlert(`register${role.charAt(0).toUpperCase() + role.slice(1)}Alert`, 
      'ID sudah terdaftar!', 'error');
    return;
  }
  
  // Add user
  storage.addItem('users', newUser);
  
  // Add to role-specific collection
  const roleData = {
    [role === 'mahasiswa' ? 'nim' : 'nip']: newUser.id,
    nama: newUser.nama,
    email: newUser.email,
    wa: formData.get('wa'),
    prodi: formData.get('prodi'),
    registeredAt: newUser.registeredAt
  };
  
  if (role === 'mahasiswa') {
    roleData.tahunMasuk = parseInt(formData.get('tahunMasuk'));
    roleData.pembimbing1 = '';
    roleData.pembimbing2 = '';
  } else {
    roleData.keahlian = formData.get('keahlian');
  }
  
  storage.addItem(role, roleData);
  
  showAlert(`register${role.charAt(0).toUpperCase() + role.slice(1)}Alert`, 
    'Registrasi berhasil! Silakan login.', 'success');
  form.reset();
  
  // Switch to login tab
  setTimeout(() => {
    document.querySelector('[data-tab="loginForm"]').click();
  }, 1500);
}

function handleLogout() {
  if (confirm('Yakin ingin logout?')) {
    currentUser = null;
    sessionStorage.removeItem('currentUser');
    showLogin();
  }
}

function showLogin() {
  document.getElementById('loginSection').style.display = 'flex';
  document.getElementById('dashboardSection').classList.remove('active');
}

function showDashboard() {
  document.getElementById('loginSection').style.display = 'none';
  document.getElementById('dashboardSection').classList.add('active');
  
  // Update user info
  document.getElementById('userName').textContent = currentUser.nama;
  document.getElementById('userRole').textContent = currentUser.role;
  
  // Setup navigation based on role
  setupNavigation();
  
  // Load home section
  navigateToSection('home');
}

function setupNavigation() {
  const navMenu = document.getElementById('navMenu');
  navMenu.innerHTML = '';
  
  const menuItems = {
    admin: [
      {id: 'home', label: '🏠 Dashboard', icon: '📊'},
      {id: 'mahasiswa', label: '👨‍🎓 Mahasiswa', icon: '👥'},
      {id: 'dosen', label: '👨‍🏫 Dosen', icon: '🎓'},
      {id: 'proposal', label: '📄 Proposal', icon: '📋'},
      {id: 'bimbingan', label: '📚 Bimbingan', icon: '📖'},
      {id: 'repository', label: '🗂️ Repository', icon: '💾'},
      {id: 'settings', label: '⚙️ Settings', icon: '🔧'}
    ],
    mahasiswa: [
      {id: 'home', label: '🏠 Dashboard', icon: '📊'},
      {id: 'myproposal', label: '📄 Proposal Saya', icon: '📋'},
      {id: 'mybimbingan', label: '📚 Bimbingan Saya', icon: '📖'},
      {id: 'repository', label: '🗂️ Repository', icon: '💾'}
    ],
    dosen: [
      {id: 'home', label: '🏠 Dashboard', icon: '📊'},
      {id: 'mybimbingan', label: '👥 Mahasiswa Bimbingan', icon: '📖'},
      {id: 'proposal', label: '📄 Review Proposal', icon: '📋'},
      {id: 'repository', label: '🗂️ Repository', icon: '💾'}
    ]
  };
  
  const items = menuItems[currentUser.role] || menuItems.mahasiswa;
  
  items.forEach(item => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = '#';
    a.className = 'nav-link';
    a.dataset.section = item.id;
    a.textContent = item.label;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      navigateToSection(item.id);
    });
    li.appendChild(a);
    navMenu.appendChild(li);
  });
}

function navigateToSection(sectionId) {
  currentSection = sectionId;
  
  // Update nav active state
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.section === sectionId);
  });
  
  // Hide all sections
  document.querySelectorAll('.content-section').forEach(section => {
    section.classList.remove('active');
  });
  
  // Show target section
  const targetSection = document.getElementById(`section-${sectionId}`);
  if (targetSection) {
    targetSection.classList.add('active');
  }
  
  // Load section data
  loadSectionData(sectionId);
}

// ============= SECTION DATA LOADING =============
function loadSectionData(sectionId) {
  switch(sectionId) {
    case 'home':
      loadHomeStats();
      break;
    case 'mahasiswa':
      loadMahasiswaTable();
      break;
    case 'dosen':
      loadDosenTable();
      break;
    case 'proposal':
      loadProposalTable();
      break;
    case 'bimbingan':
      loadBimbinganTable();
      break;
    case 'repository':
      loadRepositoryTable();
      break;
    case 'myproposal':
      loadMyProposal();
      break;
    case 'mybimbingan':
      loadMyBimbingan();
      break;
  }
}

function loadHomeStats() {
  const data = storage.getData();
  
  document.getElementById('statMahasiswa').textContent = data.mahasiswa.length;
  document.getElementById('statDosen').textContent = data.dosen.length;
  document.getElementById('statProposal').textContent = data.proposals.length;
  document.getElementById('statRepository').textContent = data.repository.length;
}

function loadMahasiswaTable() {
  const mahasiswa = storage.getCollection('mahasiswa');
  const tbody = document.getElementById('mahasiswaTableBody');
  
  if (mahasiswa.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center">Belum ada data mahasiswa</td></tr>';
    return;
  }
  
  tbody.innerHTML = mahasiswa.map(mhs => `
    <tr>
      <td>${mhs.nim}</td>
      <td>${mhs.nama}</td>
      <td>${mhs.email}</td>
      <td>${mhs.prodi}</td>
      <td>${mhs.tahunMasuk}</td>
      <td>${mhs.pembimbing1 || '-'}</td>
      <td>
        <button class="btn btn-sm btn-success" onclick="editMahasiswa('${mhs.nim}')">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteMahasiswa('${mhs.nim}')">Hapus</button>
      </td>
    </tr>
  `).join('');
}

function loadDosenTable() {
  const dosen = storage.getCollection('dosen');
  const tbody = document.getElementById('dosenTableBody');
  
  if (dosen.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center">Belum ada data dosen</td></tr>';
    return;
  }
  
  tbody.innerHTML = dosen.map(dsn => `
    <tr>
      <td>${dsn.nip}</td>
      <td>${dsn.nama}</td>
      <td>${dsn.email}</td>
      <td>${dsn.keahlian}</td>
      <td>${dsn.prodi}</td>
      <td>
        <button class="btn btn-sm btn-success" onclick="editDosen('${dsn.nip}')">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteDosen('${dsn.nip}')">Hapus</button>
      </td>
    </tr>
  `).join('');
}

// ============= UTILITIES =============
function showAlert(elementId, message, type) {
  const alert = document.getElementById(elementId);
  alert.className = `alert alert-${type} show`;
  alert.textContent = message;
  
  setTimeout(() => {
    alert.classList.remove('show');
  }, 3000);
}

function showModal(modalId) {
  document.getElementById(modalId).classList.add('show');
}

function hideModal(modalId) {
  document.getElementById(modalId).classList.remove('show');
}

// ============= CRUD OPERATIONS =============
function addMahasiswa() {
  showModal('mahasiswaModal');
  document.getElementById('mahasiswaForm').reset();
  document.getElementById('mahasiswaModalTitle').textContent = 'Tambah Mahasiswa';
}

function editMahasiswa(nim) {
  const mhs = storage.findItem('mahasiswa', nim, 'nim');
  if (!mhs) return;
  
  showModal('mahasiswaModal');
  document.getElementById('mahasiswaModalTitle').textContent = 'Edit Mahasiswa';
  document.getElementById('mahasiswaForm').reset();
  
  // Fill form
  Object.keys(mhs).forEach(key => {
    const input = document.querySelector(`#mahasiswaForm [name="${key}"]`);
    if (input) input.value = mhs[key];
  });
}

function deleteMahasiswa(nim) {
  if (confirm('Yakin hapus mahasiswa ini?')) {
    storage.deleteItem('mahasiswa', nim, 'nim');
    storage.deleteItem('users', nim, 'id');
    loadMahasiswaTable();
  }
}

// Similar functions for Dosen, Proposal, etc.

// Export for global access
window.navigateToSection = navigateToSection;
window.addMahasiswa = addMahasiswa;
window.editMahasiswa = editMahasiswa;
window.deleteMahasiswa = deleteMahasiswa;
window.showModal = showModal;
window.hideModal = hideModal;

