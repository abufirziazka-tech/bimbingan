/**
 * FEBI Dashboard Configuration
 * Edit file ini untuk customisasi dashboard
 */

const CONFIG = {
  // Informasi Institusi
  institution: {
    name: 'FEBI UINSI Samarinda',
    fullName: 'Fakultas Ekonomi dan Bisnis Islam - Universitas Islam Negeri Samarinda',
    logo: 'assets/logo.png',
    website: 'https://febi.uinsi.ac.id'
  },

  // Program Studi
  programs: [
    'Ekonomi Syariah',
    'Perbankan Syariah',
    'Manajemen Bisnis Syariah'
  ],

  // Default Admin Account
  defaultAdmin: {
    id: 'ADMIN001',
    password: 'admin123',
    role: 'admin',
    nama: 'Administrator',
    email: 'admin@febi.uinsi.ac.id'
  },

  // Storage Settings
  storage: {
    type: 'localStorage', // 'localStorage' atau 'googleSheets'
    prefix: 'febiDashboard_',
    autoBackup: true,
    backupInterval: 3600000 // 1 hour in milliseconds
  },

  // Google Sheets Integration (Optional)
  googleSheets: {
    enabled: false,
    sheetId: '1cevqxEjjrpyfPRY1aTHdcfDNe5uEUkdLDtaO445TRUw',
    apiKey: '', // Optional: Google Sheets API Key untuk read-only
    publishedUrl: '' // Published sheet URL for CSV export
  },

  // UI Settings
  ui: {
    theme: {
      primaryColor: '#1e5631',
      secondaryColor: '#2d8659',
      accentColor: '#3ba876',
      dangerColor: '#dc3545',
      warningColor: '#ffc107',
      successColor: '#28a745'
    },
    itemsPerPage: 10,
    dateFormat: 'DD/MM/YYYY',
    timeFormat: 'HH:mm'
  },

  // Bimbingan Configuration
  bimbingan: {
    babs: ['Bab 1', 'Bab 2', 'Bab 3', 'Bab 4', 'Bab 5'],
    statusOptions: ['Draft', 'Revisi', 'ACC']
  },

  // Proposal Configuration
  proposal: {
    similarityThreshold: 30, // Percentage
    statusOptions: ['Pending', 'Revisi', 'Disetujui', 'Ditolak']
  },

  // Features Toggle
  features: {
    registration: true, // Allow mahasiswa/dosen self-registration
    proposalSubmission: true,
    similarityCheck: true,
    repository: true,
    notifications: true,
    export: true,
    import: true
  },

  // Advanced Settings
  advanced: {
    debug: false, // Set true untuk detailed logging
    cacheTimeout: 300000, // 5 minutes
    maxFileSize: 10485760, // 10MB in bytes
    allowedFileTypes: ['pdf', 'doc', 'docx']
  }
};

// Export configuration
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG;
}
