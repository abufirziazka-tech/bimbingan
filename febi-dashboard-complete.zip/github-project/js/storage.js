/**
 * FEBI Dashboard - Storage Management
 * Mengelola penyimpanan data di LocalStorage
 */

class StorageManager {
  constructor() {
    this.prefix = CONFIG.storage.prefix || 'febiDashboard_';
    this.dataKey = this.prefix + 'data';
    this.backupKey = this.prefix + 'backup';
    this.init();
  }

  /**
   * Initialize storage
   */
  init() {
    if (!this.exists()) {
      this.createDefault();
    }
    
    if (CONFIG.storage.autoBackup) {
      this.setupAutoBackup();
    }
    
    this.log('Storage initialized');
  }

  /**
   * Check if data exists
   */
  exists() {
    return localStorage.getItem(this.dataKey) !== null;
  }

  /**
   * Create default data structure
   */
  createDefault() {
    const defaultData = {
      users: [CONFIG.defaultAdmin],
      mahasiswa: [],
      dosen: [],
      proposals: [],
      bimbingan: [],
      repository: [],
      settings: {
        initialized: new Date().toISOString(),
        version: '1.0.0'
      }
    };

    this.save(defaultData);
    this.log('Default data created');
  }

  /**
   * Get all data
   */
  getData() {
    try {
      const data = localStorage.getItem(this.dataKey);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      this.error('Error getting data:', error);
      return null;
    }
  }

  /**
   * Save all data
   */
  save(data) {
    try {
      localStorage.setItem(this.dataKey, JSON.stringify(data));
      localStorage.setItem(this.prefix + 'lastSave', new Date().toISOString());
      this.log('Data saved successfully');
      return true;
    } catch (error) {
      this.error('Error saving data:', error);
      return false;
    }
  }

  /**
   * Get specific collection
   */
  getCollection(name) {
    const data = this.getData();
    return data ? data[name] || [] : [];
  }

  /**
   * Save specific collection
   */
  saveCollection(name, collection) {
    const data = this.getData();
    if (data) {
      data[name] = collection;
      return this.save(data);
    }
    return false;
  }

  /**
   * Add item to collection
   */
  addItem(collectionName, item) {
    const collection = this.getCollection(collectionName);
    collection.push(item);
    return this.saveCollection(collectionName, collection);
  }

  /**
   * Update item in collection
   */
  updateItem(collectionName, id, updates, idField = 'id') {
    const collection = this.getCollection(collectionName);
    const index = collection.findIndex(item => item[idField] === id);
    
    if (index !== -1) {
      collection[index] = { ...collection[index], ...updates };
      return this.saveCollection(collectionName, collection);
    }
    
    return false;
  }

  /**
   * Delete item from collection
   */
  deleteItem(collectionName, id, idField = 'id') {
    const collection = this.getCollection(collectionName);
    const filtered = collection.filter(item => item[idField] !== id);
    
    if (filtered.length !== collection.length) {
      return this.saveCollection(collectionName, filtered);
    }
    
    return false;
  }

  /**
   * Find item in collection
   */
  findItem(collectionName, id, idField = 'id') {
    const collection = this.getCollection(collectionName);
    return collection.find(item => item[idField] === id);
  }

  /**
   * Search items in collection
   */
  searchItems(collectionName, query, fields = []) {
    const collection = this.getCollection(collectionName);
    const lowerQuery = query.toLowerCase();
    
    return collection.filter(item => {
      return fields.some(field => {
        const value = item[field];
        return value && value.toString().toLowerCase().includes(lowerQuery);
      });
    });
  }

  /**
   * Filter items in collection
   */
  filterItems(collectionName, filterFn) {
    const collection = this.getCollection(collectionName);
    return collection.filter(filterFn);
  }

  /**
   * Create backup
   */
  createBackup() {
    try {
      const data = this.getData();
      const backup = {
        data: data,
        timestamp: new Date().toISOString(),
        version: data.settings.version
      };
      
      localStorage.setItem(this.backupKey, JSON.stringify(backup));
      this.log('Backup created');
      return true;
    } catch (error) {
      this.error('Error creating backup:', error);
      return false;
    }
  }

  /**
   * Restore from backup
   */
  restoreBackup() {
    try {
      const backup = localStorage.getItem(this.backupKey);
      if (backup) {
        const parsed = JSON.parse(backup);
        this.save(parsed.data);
        this.log('Backup restored');
        return true;
      }
      return false;
    } catch (error) {
      this.error('Error restoring backup:', error);
      return false;
    }
  }

  /**
   * Setup auto backup
   */
  setupAutoBackup() {
    setInterval(() => {
      this.createBackup();
    }, CONFIG.storage.backupInterval);
    
    this.log('Auto backup enabled');
  }

  /**
   * Export data as JSON
   */
  exportJSON() {
    const data = this.getData();
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `febi-dashboard-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    this.log('Data exported');
  }

  /**
   * Import data from JSON
   */
  async importJSON(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          
          // Validate data structure
          if (this.validateData(data)) {
            this.save(data);
            this.log('Data imported successfully');
            resolve(true);
          } else {
            reject(new Error('Invalid data structure'));
          }
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = () => reject(new Error('File read error'));
      reader.readAsText(file);
    });
  }

  /**
   * Validate data structure
   */
  validateData(data) {
    const requiredKeys = ['users', 'mahasiswa', 'dosen', 'proposals', 'bimbingan', 'repository'];
    return requiredKeys.every(key => Array.isArray(data[key]));
  }

  /**
   * Clear all data
   */
  clear() {
    localStorage.removeItem(this.dataKey);
    localStorage.removeItem(this.backupKey);
    this.createDefault();
    this.log('Storage cleared and reset');
  }

  /**
   * Get statistics
   */
  getStats() {
    const data = this.getData();
    if (!data) return null;

    return {
      users: data.users.length,
      mahasiswa: data.mahasiswa.length,
      dosen: data.dosen.length,
      proposals: data.proposals.length,
      bimbingan: data.bimbingan.length,
      repository: data.repository.length,
      lastSave: localStorage.getItem(this.prefix + 'lastSave'),
      storageSize: new Blob([JSON.stringify(data)]).size
    };
  }

  /**
   * Logging helper
   */
  log(...args) {
    if (CONFIG.advanced.debug) {
      console.log('[Storage]', ...args);
    }
  }

  /**
   * Error logging helper
   */
  error(...args) {
    console.error('[Storage Error]', ...args);
  }
}

// Create global instance
const storage = new StorageManager();
